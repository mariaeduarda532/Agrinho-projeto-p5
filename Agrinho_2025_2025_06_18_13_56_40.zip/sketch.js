let minhaImagem;

function preload() {
  // Carrega a imagem antes do programa iniciar
  minhaImagem = loadImage('caminho/para/sua/paisagem.jpg');
}

let perguntas = [
  "O que significa a palavra Agrinho?",
  "Quais são as ações do Agrinho?",
  "Como surgiu o Agrinho?",
  "Você prefere morar na cidade ou no campo?"
];

let respostas = [];
let perguntaAtual = 0;
let respondendo = true;

function setup() {
  createCanvas(600, 400);
  textSize(20);
  textAlign(CENTER, CENTER);
  text ("Clique para começar", width / 2, height / 2);
  
  // Inicia a primeira pergunta
  perguntar();
}

function draw() {
  background(255);

  // Se estiver respondendo, mostra a pergunta atual
  if (respondendo) {
    text("Pergunta: " + perguntas[perguntaAtual], width / 2, height / 4);
    text("Clique para responder", width / 2, height / 2);
  } else {
    // Exibe as respostas quando terminar
    text("Respostas:", width / 2, height / 4);
    for (let i = 0; i < respostas.length; i++) {
      text(perguntas[i] + "\n" + respostas[i], width / 2, height / 2 + 40 * i);
    }
  }
}

function mousePressed() {
  if (respondendo) {
    let resposta = prompt(perguntas[perguntaAtual]);
    
    if (resposta !== null) {
      respostas.push(resposta);
      perguntaAtual++;
    }
    
    // Quando todas as perguntas forem respondidas, para o processo
    if (perguntaAtual >= perguntas.length) {
      respondendo = false;
    }
  }
}

function perguntar() {
  if (perguntaAtual < perguntas.length) {
    let resposta = prompt(perguntas[perguntaAtual]);
    respostas.push(resposta);
    perguntaAtual++;
  }
}
